# DECISIONS.md

## Stack

- **Backend:** Node.js + Express. Straightforward, well-understood, easy for Marcus's
  future maintainers to pick up.
- **Database:** SQLite via `better-sqlite3`, not Postgres or MongoDB. This is the one
  deliberate deviation from the brief's "expected shape," so it deserves the most
  explanation: SQLite is a real, persisted, transactional SQL database — not a JSON
  file and not an in-memory store. For a single-tenant app with one config document
  and a low-volume leads table, it removes an entire category of setup friction
  (no separate DB service to provision, connect, and keep alive) without giving up
  any of the constraints that matter for this brief: server-side-only calculation,
  real persistence across restarts, and no schema surprises. The schema
  (`configs`, `leads`, `owners` tables, see `server/src/config/db.js`) is plain SQL
  and would port to Postgres with minimal changes if Northline outgrows a single
  SQLite file — that's one of the "before production" questions below.
- **Frontend:** React + Vite + Tailwind, no meta-framework. The app is two flat
  client-rendered surfaces talking to one API; Next.js's routing/SSR machinery
  wasn't buying anything here.
- **Auth:** JWT bearer tokens over a login endpoint, not the Basic Auth snippet shown
  in the brief's example code. Basic Auth would re-prompt the browser's native
  credential dialog on every session and doesn't give a clean "log out" affordance,
  which matters for a shared Dale/Marcus login. A JWT with a 12-hour expiry gets the
  same "it's fine, not a security exercise" simplicity with a normal login screen.

## The pricing formula, in plain language

For a given roof:

1. Take the roof's square footage and multiply by the chosen material's cost per
   square foot, then add 10% on top for wasted material (offcuts, mistakes).
2. Add the cost of tearing off the old roof, which depends on how many layers of
   old roofing are already up there (more layers = more labor).
3. Multiply that whole subtotal by two adjustments: how steep the roof is (steeper
   roofs take longer and need more safety gear) and how many storeys the house has
   (taller means more scaffolding/ladder time).
4. Add a flat $350 permit fee.
5. That number is the *midpoint* estimate. The actual quote could reasonably land
   12% above or below it depending on site specifics we can't know from a form, so
   we show the customer a low and a high number instead of a single misleadingly
   precise figure.

All of this runs only on the server (`server/src/services/calculator.js`). The
browser never sees rates, multipliers logic, or the formula — only the final range.

## What was deliberately left out of scope

- **Role permissions.** Dale and Marcus share one login. The brief describes two
  people who both need full access, not two access levels — building a permissions
  system for that would be solving a problem nobody asked for.
- **Multi-tenancy.** This is one business, one config, one database. No
  tenant/business ID anywhere in the schema.
- **Concurrent-edit conflict handling.** If Dale and Marcus both open the config
  editor and save at the same time, last write wins. Worth fixing before this
  becomes a real product with more than two editors; not worth building for two
  people who work in the same office.
- **Config version history / rollback UI.** The schema already keeps every past
  config version as an inactive row (see `configModel.js`), so the data isn't
  thrown away — but there's no owner-facing screen to browse or revert to it. A
  stretch goal noted below.
- **Rich form validation UX** (e.g. inline "3 layers isn't a real option" typing
  hints). The wizard blocks bad input before submit and the server independently
  re-validates and rejects anything that slips through; that's enough for a
  4-question form.

## Seed data oddities and how they were handled

- **`pitch.medium.multiplier` arrives as the string `"1.12"`**, not a number, while
  every sibling value is a number. The seed script normalizes every
  rate/multiplier field through `Number()` on write, and the calculation engine
  does the same defensively on read — so a string slipping into the config editor
  later (e.g. an owner typing into a number field oddly) can't silently break
  arithmetic or turn into string concatenation.
- **`ld_0917` (Bill Tanner) references `config_version: 1`**, a schema that no
  longer exists — it has `slate_natural` as a material and two fields
  (`chimney_count`, `gutter_replace`) that aren't questions anywhere in v3. Rather
  than trying to force this old lead into the current question shape (which would
  mean inventing data that was never collected), leads are stored as an opaque
  answers blob tagged with the config_version they were captured under. The owner
  panel just renders whatever keys are present for that lead. This means old leads
  stay readable forever even as the question set evolves — which is exactly the
  kind of thing Dale asked for ("I might want to add a question later, or drop
  one") without anyone needing to write a migration.
- **Historical `estimate_low`/`estimate_high` on the seed leads** are the client's
  real numbers from whatever system produced them before. They are not
  recalculated against this build's formula on load — doing so would quietly
  rewrite the client's own historical data to match a formula that didn't exist
  yet when those leads came in.

## Questions for Dale before a real production launch

1. Who else, besides you and Marcus, should ever be able to log into the panel —
   and should logins be per-person instead of one shared password?
2. When a lead comes in, do you want an email/SMS notification, or is checking the
   panel manually enough for now?
3. Is $350 really a flat permit fee everywhere you operate, or does it vary by
   township/county? Columbus-area permit costs can differ block to block.
4. Should the estimator ever show a "we don't service this material/pitch
   combination" message instead of a price — is every combination in the current
   config actually something your crew will do?
5. Do you want leads that never convert to a job removed or archived after some
   period, or kept forever?

## What I'd do next with another week

- Move persistence to Postgres and add a proper migration tool (Prisma or
  Drizzle) instead of hand-written SQL in `db.js`.
- Per-owner accounts (so "Dale changed a price" vs. "Marcus changed a price" is
  distinguishable) instead of one shared login.
- A config version history screen using the data the schema already keeps.
- CSV export and an outbound webhook for new leads, per the stretch goals.
- Automated tests around `calculator.js` — it's the one file where a silent bug
  costs Dale real money on every quote, and it's the easiest thing in the codebase
  to unit test exhaustively.
