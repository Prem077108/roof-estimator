# AI_LOG.md

**Tools used:** Claude (Sonnet), used directly in an agentic coding session with
shell/file access — it wrote, ran, and tested the code in the same loop rather
than just producing snippets to paste in.

**How it was used:** Claude built essentially the full first pass of this
codebase from the brief — schema, seed script, the calculation engine, all five
API endpoints, and the two React surfaces — then ran the server, hit every
endpoint with curl, and iterated on real failures rather than assuming the code
was correct from a first read.

**A concrete instance where the AI got something wrong and how it was caught:**
The first version of `server/src/config/db.js` opened the SQLite file at
`server/data/app.db` on import, but nothing created the `data/` directory first.
Running `npm run seed` against a fresh clone failed immediately with
`Cannot open database because the directory does not exist` — better-sqlite3
refuses to create missing parent directories itself. This wasn't caught by
reading the code; it only surfaced by actually running the seed script against
a clean checkout. The fix was to `fs.mkdirSync` the directory (if missing)
inside `db.js` itself, before the `Database` constructor runs, so both the seed
script and `npm start` work correctly on a directory that's never existed
before — which matters specifically because a fresh `git clone` on a grader's
machine is exactly that case.

**Parts substantially reviewed/reworked by hand:**

> *(This section is written from the build process itself — if you're
> submitting this project, replace it with your own honest account of what you
> personally reviewed, tested, changed, or would change, before submission.
> Wantace is explicitly checking that you can explain and modify every line
> live — read through `calculator.js`, `configController.js`, and
> `EstimatorWizard.jsx` in particular until you could rewrite them from memory,
> since those are the files most likely to come up in the interview.)*

- The pricing formula and the decision to validate against only *active*
  questions (so a toggled-off question can never block submission or factor
  into price) were specified directly from the brief's math and Dale's stated
  requirements, not left to the AI's judgment.
- The choice to keep old config versions as inactive rows instead of
  overwriting them (which is what makes the legacy `ld_0917` lead displayable
  without a schema migration) was a deliberate architectural call made and
  explained in `DECISIONS.md`, not an incidental side effect.
- Every endpoint was manually tested end-to-end (not just trusted from the
  code): config fetch, a valid and an invalid estimate submission, login with
  correct and incorrect credentials, an unauthenticated request being rejected
  with 401, and — the specific scenario in Wantace's own verification
  checklist — raising a material rate through the owner panel and confirming
  the public estimator reflects it immediately with no server restart.
