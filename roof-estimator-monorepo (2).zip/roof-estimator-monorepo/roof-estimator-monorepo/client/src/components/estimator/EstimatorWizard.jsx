// client/src/components/estimator/EstimatorWizard.jsx
import { useEffect, useState } from 'react';
import { fetchConfig, submitEstimate } from '../../services/api';
import QuestionField from '../dynamic/QuestionField';

const STEP = {
  LOADING: 'loading',
  QUESTIONS: 'questions',
  CONTACT: 'contact',
  RESULT: 'result',
  ERROR: 'error',
};

export default function EstimatorWizard() {
  const [step, setStep] = useState(STEP.LOADING);
  const [config, setConfig] = useState(null);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [fieldError, setFieldError] = useState(null);
  const [contact, setContact] = useState({ name: '', phone: '', email: '' });
  const [contactErrors, setContactErrors] = useState({});
  const [result, setResult] = useState(null);
  const [submitError, setSubmitError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [loadError, setLoadError] = useState(null);

  useEffect(() => {
    fetchConfig()
      .then((data) => {
        setConfig(data);
        setStep(STEP.QUESTIONS);
      })
      .catch((err) => {
        setLoadError(err.message);
        setStep(STEP.ERROR);
      });
  }, []);

  if (step === STEP.LOADING) {
    return <CenteredCard>Loading your estimator…</CenteredCard>;
  }

  if (step === STEP.ERROR) {
    return (
      <CenteredCard>
        <p className="text-red-600 font-medium">Something went wrong loading the estimator.</p>
        <p className="text-slate-500 text-sm mt-2">{loadError}</p>
      </CenteredCard>
    );
  }

  const questions = config.questions;
  const currentQuestion = questions[questionIndex];

  function handleAnswer(key, value) {
    setAnswers((prev) => ({ ...prev, [key]: value }));
    setFieldError(null);
  }

  function goNext() {
    const value = answers[currentQuestion.key];
    if (currentQuestion.required && (value === undefined || value === '' || value === null)) {
      setFieldError('Please answer this question to continue.');
      return;
    }
    if (currentQuestion.type === 'number') {
      const num = Number(value);
      if (Number.isNaN(num)) {
        setFieldError('Please enter a valid number.');
        return;
      }
      if (currentQuestion.min !== undefined && num < currentQuestion.min) {
        setFieldError(`Must be at least ${currentQuestion.min}.`);
        return;
      }
      if (currentQuestion.max !== undefined && num > currentQuestion.max) {
        setFieldError(`Must be at most ${currentQuestion.max}.`);
        return;
      }
    }

    if (questionIndex < questions.length - 1) {
      setQuestionIndex((i) => i + 1);
    } else {
      setStep(STEP.CONTACT);
    }
  }

  function goBack() {
    if (questionIndex > 0) {
      setQuestionIndex((i) => i - 1);
      setFieldError(null);
    }
  }

  function validateContact() {
    const errs = {};
    if (!contact.name.trim()) errs.name = 'Name is required.';
    if (!contact.phone.trim()) errs.phone = 'Phone is required.';
    if (!contact.email.trim() || !/^\S+@\S+\.\S+$/.test(contact.email)) errs.email = 'A valid email is required.';
    setContactErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!validateContact()) return;

    setSubmitting(true);
    setSubmitError(null);
    try {
      const data = await submitEstimate({ ...contact, answers });
      setResult(data);
      setStep(STEP.RESULT);
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (step === STEP.QUESTIONS) {
    return (
      <CenteredCard>
        <ProgressBar current={questionIndex + 1} total={questions.length} />
        <div className="mt-6">
          <QuestionField
            question={currentQuestion}
            value={answers[currentQuestion.key]}
            onChange={handleAnswer}
            error={fieldError}
          />
        </div>
        <div className="flex justify-between mt-8">
          <button
            onClick={goBack}
            disabled={questionIndex === 0}
            className="px-5 py-2 rounded-lg text-slate-500 disabled:opacity-0"
          >
            Back
          </button>
          <button
            onClick={goNext}
            className="px-6 py-2.5 rounded-lg bg-orange-600 text-white font-semibold hover:bg-orange-700 transition"
          >
            {questionIndex === questions.length - 1 ? 'Continue' : 'Next'}
          </button>
        </div>
      </CenteredCard>
    );
  }

  if (step === STEP.CONTACT) {
    return (
      <CenteredCard>
        <h2 className="text-xl font-bold text-slate-800 mb-1">Almost there</h2>
        <p className="text-slate-500 mb-6">Where should we send your estimate?</p>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <ContactInput
            label="Full name"
            value={contact.name}
            onChange={(v) => setContact((c) => ({ ...c, name: v }))}
            error={contactErrors.name}
          />
          <ContactInput
            label="Phone number"
            value={contact.phone}
            onChange={(v) => setContact((c) => ({ ...c, phone: v }))}
            error={contactErrors.phone}
          />
          <ContactInput
            label="Email"
            value={contact.email}
            onChange={(v) => setContact((c) => ({ ...c, email: v }))}
            error={contactErrors.email}
          />
          {submitError && <p className="text-red-500 text-sm">{submitError}</p>}
          <div className="flex justify-between mt-4">
            <button type="button" onClick={() => setStep(STEP.QUESTIONS)} className="px-5 py-2 rounded-lg text-slate-500">
              Back
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-2.5 rounded-lg bg-orange-600 text-white font-semibold hover:bg-orange-700 transition disabled:opacity-60"
            >
              {submitting ? 'Calculating…' : 'Get my estimate'}
            </button>
          </div>
        </form>
      </CenteredCard>
    );
  }

  if (step === STEP.RESULT) {
    const fmt = new Intl.NumberFormat('en-US', { style: 'currency', currency: config.business.currency || 'USD', maximumFractionDigits: 0 });
    return (
      <CenteredCard>
        <p className="text-slate-500 mb-1">Your estimated cost range</p>
        <p className="text-3xl md:text-4xl font-extrabold text-slate-900 mb-4">
          {fmt.format(result.estimate_low)} – {fmt.format(result.estimate_high)}
        </p>
        <p className="text-slate-500 text-sm">
          Thanks, {contact.name}! Someone from {config.business.name} will follow up shortly to confirm the details
          and firm up your final quote.
        </p>
      </CenteredCard>
    );
  }

  return null;
}

function ProgressBar({ current, total }) {
  return (
    <div>
      <div className="flex justify-between text-sm text-slate-400 mb-2">
        <span>Question {current} of {total}</span>
      </div>
      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-orange-500 transition-all"
          style={{ width: `${(current / total) * 100}%` }}
        />
      </div>
    </div>
  );
}

function ContactInput({ label, value, onChange, error }) {
  return (
    <div>
      <label className="block text-sm font-semibold text-slate-700 mb-1">{label}</label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`p-3 border rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-orange-500 ${
          error ? 'border-red-400' : 'border-slate-300'
        }`}
      />
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </div>
  );
}

function CenteredCard({ children }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4 py-10">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-sm border border-slate-100 p-6 md:p-8">
        {children}
      </div>
    </div>
  );
}
