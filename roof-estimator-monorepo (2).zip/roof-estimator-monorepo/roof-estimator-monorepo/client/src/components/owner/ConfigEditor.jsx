// client/src/components/owner/ConfigEditor.jsx
//
// Non-technical-friendly editor: plain labeled fields and toggle switches,
// no JSON editing required. Sends the whole document back on Save.

import { useState } from 'react';

export default function ConfigEditor({ config, onSave, saving, saveError, saveSuccess }) {
  const [draft, setDraft] = useState(JSON.parse(JSON.stringify(config)));

  function updateQuestion(qIndex, patch) {
    setDraft((prev) => {
      const questions = [...prev.questions];
      questions[qIndex] = { ...questions[qIndex], ...patch };
      return { ...prev, questions };
    });
  }

  function updateOption(qIndex, oIndex, patch) {
    setDraft((prev) => {
      const questions = [...prev.questions];
      const options = [...questions[qIndex].options];
      options[oIndex] = { ...options[oIndex], ...patch };
      questions[qIndex] = { ...questions[qIndex], options };
      return { ...prev, questions };
    });
  }

  function updateModifier(key, value) {
    setDraft((prev) => ({ ...prev, modifiers: { ...prev.modifiers, [key]: value } }));
  }

  return (
    <div className="flex flex-col gap-8">
      <section>
        <h2 className="text-lg font-bold text-slate-800 mb-3">Global settings</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white border border-slate-200 rounded-xl p-5">
          <NumberField
            label="Waste factor"
            hint="e.g. 0.10 = 10%"
            value={draft.modifiers.waste_factor}
            onChange={(v) => updateModifier('waste_factor', v)}
            step="0.01"
          />
          <NumberField
            label="Permit flat fee ($)"
            value={draft.modifiers.permit_flat_fee}
            onChange={(v) => updateModifier('permit_flat_fee', v)}
          />
          <NumberField
            label="Estimate spread (%)"
            hint="e.g. 12 = ±12%"
            value={draft.modifiers.range_spread_pct}
            onChange={(v) => updateModifier('range_spread_pct', v)}
          />
        </div>
      </section>

      <section>
        <h2 className="text-lg font-bold text-slate-800 mb-3">Questions</h2>
        <div className="flex flex-col gap-4">
          {draft.questions.map((q, qIndex) => (
            <div key={q.key} className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="flex items-center justify-between mb-3">
                <input
                  value={q.label}
                  onChange={(e) => updateQuestion(qIndex, { label: e.target.value })}
                  className="text-base font-semibold text-slate-800 border-b border-transparent focus:border-orange-400 focus:outline-none flex-1 mr-4"
                />
                <ToggleSwitch checked={q.active} onChange={(v) => updateQuestion(qIndex, { active: v })} label="Active" />
              </div>
              <p className="text-xs text-slate-400 mb-3">key: {q.key} · type: {q.type}</p>

              {q.type === 'number' && (
                <div className="grid grid-cols-2 gap-4">
                  <NumberField label="Min" value={q.min} onChange={(v) => updateQuestion(qIndex, { min: v })} />
                  <NumberField label="Max" value={q.max} onChange={(v) => updateQuestion(qIndex, { max: v })} />
                </div>
              )}

              {q.type === 'select' && (
                <div className="flex flex-col gap-2">
                  {q.options.map((opt, oIndex) => (
                    <div key={opt.value} className="grid grid-cols-2 gap-3 items-center border-t border-slate-100 pt-2">
                      <input
                        value={opt.label}
                        onChange={(e) => updateOption(qIndex, oIndex, { label: e.target.value })}
                        className="text-sm border border-slate-200 rounded px-2 py-1.5"
                      />
                      {opt.rate_per_sqft !== undefined && (
                        <NumberField
                          compact
                          label="$/sqft"
                          value={opt.rate_per_sqft}
                          onChange={(v) => updateOption(qIndex, oIndex, { rate_per_sqft: v })}
                          step="0.01"
                        />
                      )}
                      {opt.multiplier !== undefined && (
                        <NumberField
                          compact
                          label="Multiplier"
                          value={opt.multiplier}
                          onChange={(v) => updateOption(qIndex, oIndex, { multiplier: v })}
                          step="0.01"
                        />
                      )}
                      {opt.tear_off_per_sqft !== undefined && (
                        <NumberField
                          compact
                          label="Tear-off $/sqft"
                          value={opt.tear_off_per_sqft}
                          onChange={(v) => updateOption(qIndex, oIndex, { tear_off_per_sqft: v })}
                          step="0.01"
                        />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      <div className="flex items-center gap-4">
        <button
          onClick={() => onSave(draft)}
          disabled={saving}
          className="px-6 py-2.5 rounded-lg bg-orange-600 text-white font-semibold hover:bg-orange-700 transition disabled:opacity-60"
        >
          {saving ? 'Saving…' : 'Save changes'}
        </button>
        {saveError && <p className="text-red-500 text-sm">{saveError}</p>}
        {saveSuccess && <p className="text-green-600 text-sm">Saved — live on the public estimator now.</p>}
      </div>
    </div>
  );
}

function NumberField({ label, hint, value, onChange, step = '1', compact }) {
  return (
    <div>
      <label className={`block font-semibold text-slate-600 mb-1 ${compact ? 'text-xs' : 'text-sm'}`}>{label}</label>
      <input
        type="number"
        step={step}
        value={value ?? ''}
        onChange={(e) => onChange(e.target.value === '' ? '' : Number(e.target.value))}
        className={`border border-slate-300 rounded px-2 py-1.5 w-full ${compact ? 'text-sm' : ''}`}
      />
      {hint && <p className="text-xs text-slate-400 mt-1">{hint}</p>}
    </div>
  );
}

function ToggleSwitch({ checked, onChange, label }) {
  return (
    <label className="flex items-center gap-2 cursor-pointer select-none">
      <span className="text-xs text-slate-500">{label}</span>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={`w-10 h-6 rounded-full transition relative ${checked ? 'bg-orange-500' : 'bg-slate-300'}`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
            checked ? 'translate-x-4' : ''
          }`}
        />
      </button>
    </label>
  );
}
