// client/src/components/owner/RequireAuth.jsx
//
// Client-side redirect for UX only — the real enforcement happens on the
// server (requireOwnerAuth middleware rejects any request without a valid
// JWT). This guard just prevents flashing the panel before that 401 lands.

import { Navigate } from 'react-router-dom';

export default function RequireAuth({ children }) {
  const token = localStorage.getItem('owner_token');
  if (!token) return <Navigate to="/admin/login" replace />;
  return children;
}
