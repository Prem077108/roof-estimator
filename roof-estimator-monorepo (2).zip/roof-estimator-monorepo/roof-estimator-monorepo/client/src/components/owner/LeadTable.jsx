// client/src/components/owner/LeadTable.jsx
import { useState } from 'react';

export default function LeadTable({ leads, currency = 'USD' }) {
  const [expanded, setExpanded] = useState(null);
  const fmt = new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 });
  const dateFmt = (iso) => new Date(iso).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' });

  if (leads.length === 0) {
    return <p className="text-slate-400 text-sm">No leads captured yet.</p>;
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-slate-50 text-slate-500 text-left">
          <tr>
            <th className="p-3 font-semibold">Name</th>
            <th className="p-3 font-semibold hidden md:table-cell">Phone</th>
            <th className="p-3 font-semibold hidden md:table-cell">Submitted</th>
            <th className="p-3 font-semibold">Estimate</th>
            <th className="p-3"></th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead) => (
            <>
              <tr key={lead.id} className="border-t border-slate-100">
                <td className="p-3">
                  <div className="font-medium text-slate-800">{lead.name}</div>
                  <div className="text-slate-400 text-xs md:hidden">{lead.phone}</div>
                </td>
                <td className="p-3 hidden md:table-cell text-slate-600">{lead.phone}</td>
                <td className="p-3 hidden md:table-cell text-slate-600">{dateFmt(lead.captured_at)}</td>
                <td className="p-3 text-slate-800">
                  {fmt.format(lead.estimate_low)} – {fmt.format(lead.estimate_high)}
                </td>
                <td className="p-3 text-right">
                  <button
                    onClick={() => setExpanded(expanded === lead.id ? null : lead.id)}
                    className="text-orange-600 hover:underline text-xs font-medium"
                  >
                    {expanded === lead.id ? 'Hide' : 'Details'}
                  </button>
                </td>
              </tr>
              {expanded === lead.id && (
                <tr key={`${lead.id}-details`} className="bg-slate-50 border-t border-slate-100">
                  <td colSpan={5} className="p-4">
                    <div className="text-xs text-slate-500 mb-2">
                      Email: {lead.email} · Config version at capture: v{lead.config_version}
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {Object.entries(lead.answers).map(([key, value]) => (
                        <div key={key} className="bg-white border border-slate-200 rounded px-3 py-2">
                          <div className="text-[10px] uppercase tracking-wide text-slate-400">{key}</div>
                          <div className="text-slate-700 text-sm">{String(value)}</div>
                        </div>
                      ))}
                    </div>
                  </td>
                </tr>
              )}
            </>
          ))}
        </tbody>
      </table>
    </div>
  );
}
