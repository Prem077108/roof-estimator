// client/src/components/dynamic/QuestionField.jsx
//
// Renders a single question based on its `type`. Nothing here knows what
// the actual questions are - the shape (type, label, options, min/max) is
// entirely driven by whatever the API returned for this config.

export default function QuestionField({ question, value, onChange, error }) {
  if (question.type === 'number') {
    return (
      <div className="flex flex-col gap-2">
        <label className="text-lg font-semibold text-slate-800">
          {question.label} {question.unit ? <span className="text-slate-400 font-normal">({question.unit})</span> : null}
        </label>
        <input
          type="number"
          min={question.min}
          max={question.max}
          value={value ?? ''}
          onChange={(e) => onChange(question.key, e.target.value)}
          className={`p-3 border rounded-lg text-lg focus:outline-none focus:ring-2 focus:ring-orange-500 w-full ${
            error ? 'border-red-400' : 'border-slate-300'
          }`}
          placeholder={
            question.min !== undefined && question.max !== undefined
              ? `Between ${question.min} and ${question.max}`
              : ''
          }
        />
        {error && <p className="text-red-500 text-sm">{error}</p>}
      </div>
    );
  }

  if (question.type === 'select') {
    return (
      <div className="flex flex-col gap-2">
        <label className="text-lg font-semibold text-slate-800">{question.label}</label>
        <div className="grid grid-cols-1 gap-2">
          {(question.options || []).map((opt) => (
            <button
              type="button"
              key={opt.value}
              onClick={() => onChange(question.key, opt.value)}
              className={`text-left p-4 border rounded-lg transition ${
                value === opt.value
                  ? 'bg-orange-50 border-orange-500 ring-1 ring-orange-500 font-medium'
                  : 'border-slate-300 hover:border-slate-400'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
        {error && <p className="text-red-500 text-sm">{error}</p>}
      </div>
    );
  }

  // Unknown question type - fail gracefully rather than crashing the wizard
  return (
    <div className="text-sm text-slate-400">
      Unsupported question type "{question.type}" for "{question.label}".
    </div>
  );
}
