// client/src/pages/OwnerPanel.jsx
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchAdminConfig, updateAdminConfig, fetchLeads } from '../services/api';
import ConfigEditor from '../components/owner/ConfigEditor';
import LeadTable from '../components/owner/LeadTable';

export default function OwnerPanel() {
  const [tab, setTab] = useState('leads');
  const [config, setConfig] = useState(null);
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([fetchAdminConfig(), fetchLeads()])
      .then(([configData, leadsData]) => {
        setConfig(configData);
        setLeads(leadsData);
      })
      .catch((err) => {
        if (err.status === 401) {
          localStorage.removeItem('owner_token');
          navigate('/admin/login');
        } else {
          setLoadError(err.message);
        }
      })
      .finally(() => setLoading(false));
  }, [navigate]);

  async function handleSave(draft) {
    setSaving(true);
    setSaveError(null);
    setSaveSuccess(false);
    try {
      const updated = await updateAdminConfig(draft);
      setConfig(updated);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      setSaveError(err.message);
    } finally {
      setSaving(false);
    }
  }

  function handleLogout() {
    localStorage.removeItem('owner_token');
    navigate('/admin/login');
  }

  if (loading) return <div className="min-h-screen flex items-center justify-center text-slate-400">Loading…</div>;
  if (loadError) return <div className="min-h-screen flex items-center justify-center text-red-500">{loadError}</div>;

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
        <div>
          <h1 className="font-bold text-slate-800">Owner Panel</h1>
          <p className="text-xs text-slate-400">{config.business.name} · config v{config.config_version}</p>
        </div>
        <button onClick={handleLogout} className="text-sm text-slate-500 hover:text-slate-800">
          Log out
        </button>
      </header>

      <nav className="max-w-5xl mx-auto px-6 pt-6 flex gap-2">
        <TabButton active={tab === 'leads'} onClick={() => setTab('leads')}>
          Leads ({leads.length})
        </TabButton>
        <TabButton active={tab === 'config'} onClick={() => setTab('config')}>
          Prices & Questions
        </TabButton>
      </nav>

      <main className="max-w-5xl mx-auto px-6 py-6">
        {tab === 'leads' && <LeadTable leads={leads} currency={config.business.currency} />}
        {tab === 'config' && (
          <ConfigEditor config={config} onSave={handleSave} saving={saving} saveError={saveError} saveSuccess={saveSuccess} />
        )}
      </main>
    </div>
  );
}

function TabButton({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-t-lg text-sm font-semibold transition ${
        active ? 'bg-white border border-b-0 border-slate-200 text-orange-600' : 'text-slate-500 hover:text-slate-700'
      }`}
    >
      {children}
    </button>
  );
}
