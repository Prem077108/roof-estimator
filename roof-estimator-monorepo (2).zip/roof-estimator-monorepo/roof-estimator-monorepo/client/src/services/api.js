// client/src/services/api.js
//
// Single point of contact with the backend. Every question, label, option,
// and rate the UI ever shows comes through fetchConfig() — nothing about
// pricing or question content is hardcoded in the frontend.

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

async function request(path, options = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const error = new Error(data.error || `Request failed (${res.status})`);
    error.status = res.status;
    error.field = data.field;
    throw error;
  }

  return data;
}

export function fetchConfig() {
  return request('/config');
}

export function submitEstimate(payload) {
  return request('/estimate', { method: 'POST', body: JSON.stringify(payload) });
}

export function login(username, password) {
  return request('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
}

function authHeaders() {
  const token = localStorage.getItem('owner_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function fetchAdminConfig() {
  return request('/admin/config', { headers: authHeaders() });
}

export function updateAdminConfig(payload) {
  return request('/admin/config', { method: 'PUT', body: JSON.stringify(payload), headers: authHeaders() });
}

export function fetchLeads() {
  return request('/admin/leads', { headers: authHeaders() });
}
