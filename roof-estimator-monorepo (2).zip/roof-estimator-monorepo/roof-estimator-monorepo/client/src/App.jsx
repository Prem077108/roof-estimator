// client/src/App.jsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import EstimatorWizard from './components/estimator/EstimatorWizard';
import OwnerLogin from './pages/OwnerLogin';
import OwnerPanel from './pages/OwnerPanel';
import RequireAuth from './components/owner/RequireAuth';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<EstimatorWizard />} />
        <Route path="/admin/login" element={<OwnerLogin />} />
        <Route
          path="/admin"
          element={
            <RequireAuth>
              <OwnerPanel />
            </RequireAuth>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
