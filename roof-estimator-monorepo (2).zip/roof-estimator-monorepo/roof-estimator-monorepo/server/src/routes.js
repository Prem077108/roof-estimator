// server/src/routes.js
import { Router } from 'express';
import { getPublicConfig, getAdminConfig, updateConfig } from './controllers/configController.js';
import { postEstimate } from './controllers/estimateController.js';
import { login } from './controllers/authController.js';
import { getLeads } from './controllers/leadController.js';
import { requireOwnerAuth } from './middleware/auth.js';

const router = Router();

// --- Public ---
router.get('/config', getPublicConfig);
router.post('/estimate', postEstimate);
router.post('/auth/login', login);

// --- Protected (owner panel) ---
router.get('/admin/config', requireOwnerAuth, getAdminConfig);
router.put('/admin/config', requireOwnerAuth, updateConfig);
router.get('/admin/leads', requireOwnerAuth, getLeads);

export default router;
