// server/src/config/seed.js
//
// Loads the seed configuration (version 3) and the three historical leads
// exactly as supplied in the client brief. Run with `npm run seed`.
//
// Notes on the raw seed data (see DECISIONS.md for full discussion):
// - pitch.medium.multiplier arrives as the STRING "1.12" instead of a number.
//   We normalize every rate/multiplier field to Number() on write, so bad
//   string input never reaches the calculation engine.
// - Two of the three historical leads (ld_0917) reference config_version: 1,
//   a schema that no longer exists (different question set: slate_natural
//   material, chimney_count, gutter_replace — none of which exist in v3).
//   We do NOT try to force this legacy lead into the current schema. Leads
//   are stored as opaque answer blobs tagged with the config_version they
//   were captured under, specifically so old leads remain readable even
//   after the config changes shape. The owner panel just displays whatever
//   keys/values are present — it doesn't assume they match live questions.
// - We insert the historical leads' estimate_low/estimate_high as-is (they
//   are the client's real historical numbers) rather than recalculating them
//   against our new formula, which would silently rewrite history.

import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { db, initSchema } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, '../../data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

initSchema();

function normalizeOptions(options = []) {
  return options.map((opt) => ({
    ...opt,
    ...(opt.rate_per_sqft !== undefined && { rate_per_sqft: Number(opt.rate_per_sqft) }),
    ...(opt.multiplier !== undefined && { multiplier: Number(opt.multiplier) }),
    ...(opt.tear_off_per_sqft !== undefined && { tear_off_per_sqft: Number(opt.tear_off_per_sqft) }),
  }));
}

const seedConfig = {
  config_version: 3,
  business: { name: 'Northline Roofing & Exteriors', region: 'Columbus, OH', currency: 'USD' },
  questions: [
    {
      key: 'roof_area', label: 'Roughly how big is your roof?', type: 'number',
      unit: 'sq ft', required: true, min: 300, max: 12000, active: true,
    },
    {
      key: 'material', label: 'What material do you want?', type: 'select', required: true, active: true,
      options: normalizeOptions([
        { value: 'asphalt_3tab', label: 'Asphalt shingle - 3-tab', rate_per_sqft: 4.25 },
        { value: 'asphalt_arch', label: 'Asphalt shingle - architectural', rate_per_sqft: 5.90 },
        { value: 'metal_standing', label: 'Standing seam metal', rate_per_sqft: 12.40 },
        { value: 'cedar_shake', label: 'Cedar shake', rate_per_sqft: 11.10 },
      ]),
    },
    {
      key: 'pitch', label: 'How steep is the roof?', type: 'select', required: true, active: true,
      options: normalizeOptions([
        { value: 'low', label: 'Low - you could walk on it', multiplier: 1.0 },
        { value: 'medium', label: 'Medium', multiplier: '1.12' },
        { value: 'steep', label: 'Steep - not walkable', multiplier: 1.30 },
      ]),
    },
    {
      key: 'layers', label: 'How many layers of old roofing are on there now?', type: 'select', required: true, active: true,
      options: normalizeOptions([
        { value: '0', label: 'None - new build', tear_off_per_sqft: 0 },
        { value: '1', label: 'One layer', tear_off_per_sqft: 1.15 },
        { value: '2', label: 'Two or more layers', tear_off_per_sqft: 2.05 },
      ]),
    },
    {
      key: 'stories', label: 'How many stories is the house?', type: 'select', required: true, active: true,
      options: normalizeOptions([
        { value: '1', label: 'Single storey', multiplier: 1.0 },
        { value: '2', label: 'Two storeys', multiplier: 1.08 },
        { value: '3', label: 'Three or more', multiplier: 1.18 },
      ]),
    },
  ],
  modifiers: { waste_factor: 0.10, permit_flat_fee: 350, range_spread_pct: 12 },
};

const seedLeads = [
  {
    id: 'ld_1041', captured_at: '2026-06-02T14:20:11Z', config_version: 3,
    name: 'Ana Ruiz', phone: '+1-614-555-0148', email: 'aruiz@example.com',
    answers: { roof_area: 2100, material: 'asphalt_arch', pitch: 'medium', layers: '1', stories: '2' },
    estimate_low: 21480, estimate_high: 27260,
  },
  {
    id: 'ld_0917', captured_at: '2026-03-18T09:02:44Z', config_version: 1,
    name: 'Bill Tanner', phone: '+1-614-555-0192', email: 'btanner@example.com',
    answers: { roof_area: 1450, material: 'slate_natural', pitch: 'steep', chimney_count: 2, gutter_replace: 'yes' },
    estimate_low: 38900, estimate_high: 44100,
  },
  {
    id: 'ld_1102', captured_at: '2026-07-11T18:47:03Z', config_version: 3,
    name: 'Priya Nair', phone: '+1-614-555-0177', email: 'pnair@example.com',
    answers: { roof_area: 900, material: 'metal_standing', pitch: 'low', layers: '0', stories: '1' },
    estimate_low: 12240, estimate_high: 15530,
  },
];

const tx = db.transaction(() => {
  db.exec('DELETE FROM configs; DELETE FROM leads; DELETE FROM owners;');

  db.prepare(
    `INSERT INTO configs (config_version, business_json, questions_json, modifiers_json, is_active)
     VALUES (?, ?, ?, ?, 1)`
  ).run(
    seedConfig.config_version,
    JSON.stringify(seedConfig.business),
    JSON.stringify(seedConfig.questions),
    JSON.stringify(seedConfig.modifiers)
  );

  const insertLead = db.prepare(
    `INSERT INTO leads (id, captured_at, config_version, name, phone, email, answers_json, estimate_low, estimate_high)
     VALUES (@id, @captured_at, @config_version, @name, @phone, @email, @answers_json, @estimate_low, @estimate_high)`
  );
  for (const lead of seedLeads) {
    insertLead.run({ ...lead, answers_json: JSON.stringify(lead.answers) });
  }

  const adminUser = process.env.ADMIN_USERNAME || 'admin';
  const adminPass = process.env.ADMIN_PASSWORD || 'roofing2026!';
  const hash = bcrypt.hashSync(adminPass, 10);
  db.prepare('INSERT INTO owners (username, password_hash) VALUES (?, ?)').run(adminUser, hash);
});

tx();

console.log('Seed complete: 1 active config (v3), 3 leads, 1 owner account.');
console.log(`Owner login -> username: ${process.env.ADMIN_USERNAME || 'admin'} / password: ${process.env.ADMIN_PASSWORD || 'roofing2026!'}`);
