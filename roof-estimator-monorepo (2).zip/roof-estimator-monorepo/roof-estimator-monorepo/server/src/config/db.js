// server/src/config/db.js
//
// Persistence layer. We use SQLite (via better-sqlite3) as a real, embedded,
// file-persisted SQL database — not an in-memory store and not a hand-rolled
// JSON file. See DECISIONS.md for why SQLite was chosen over Postgres/Mongo
// for this build, and how to swap to Postgres for production.

import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = process.env.DATABASE_URL || path.join(__dirname, '../../data/app.db');

const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

export function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS configs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      config_version INTEGER NOT NULL,
      business_json TEXT NOT NULL,
      questions_json TEXT NOT NULL,
      modifiers_json TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS leads (
      id TEXT PRIMARY KEY,
      captured_at TEXT NOT NULL DEFAULT (datetime('now')),
      config_version INTEGER NOT NULL,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      answers_json TEXT NOT NULL,
      estimate_low INTEGER NOT NULL,
      estimate_high INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS owners (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL
    );
  `);
}
