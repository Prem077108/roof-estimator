// server/src/index.js
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initSchema, db } from './config/db.js';
import routes from './routes.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Ensure the DB + schema exist even on a totally fresh clone/deploy.
const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
initSchema();

// If there's no owner account yet (fresh DB, seed never ran), auto-seed once
// so the app is never in a broken "no config / can't log in" state.
const ownerCount = db.prepare('SELECT COUNT(*) as c FROM owners').get().c;
if (ownerCount === 0) {
  console.log('No owner account found — running initial seed...');
  await import('./config/seed.js');
}

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api', routes);

app.get('/api/health', (req, res) => res.json({ ok: true }));

// Generic error handler so an unexpected exception returns JSON, not an HTML
// stack trace, to the frontend.
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Roof estimator API listening on http://localhost:${PORT}`);
});
