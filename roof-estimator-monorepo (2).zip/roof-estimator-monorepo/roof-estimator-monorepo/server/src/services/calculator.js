// server/src/services/calculator.js
//
// Deterministic, server-only pricing engine. Nothing in this file is ever
// sent to the browser as code — only the final estimate_low/estimate_high
// numbers cross the wire. See DECISIONS.md for the formula in plain English.

export class ValidationError extends Error {
  constructor(message, field) {
    super(message);
    this.name = 'ValidationError';
    this.field = field;
  }
}

function getQuestion(questions, key) {
  return questions.find((q) => q.key === key);
}

function getSelectedOption(question, selectedValue) {
  if (!question || !question.options) return null;
  return question.options.find((opt) => String(opt.value) === String(selectedValue)) || null;
}

/**
 * Validates raw answers against the active config's question definitions.
 * Only ACTIVE, required questions are enforced — a question the owner has
 * toggled off should never block submission or be used in pricing.
 */
export function validateAnswers(config, answers) {
  const { questions } = config;

  for (const q of questions) {
    if (!q.active) continue;
    const value = answers[q.key];

    if (q.required && (value === undefined || value === null || value === '')) {
      throw new ValidationError(`${q.label} is required.`, q.key);
    }
    if (value === undefined || value === null || value === '') continue;

    if (q.type === 'number') {
      const num = Number(value);
      if (Number.isNaN(num)) {
        throw new ValidationError(`${q.label} must be a number.`, q.key);
      }
      if (q.min !== undefined && num < q.min) {
        throw new ValidationError(`${q.label} must be at least ${q.min}.`, q.key);
      }
      if (q.max !== undefined && num > q.max) {
        throw new ValidationError(`${q.label} must be at most ${q.max}.`, q.key);
      }
    }

    if (q.type === 'select') {
      const opt = getSelectedOption(q, value);
      if (!opt) {
        throw new ValidationError(`${q.label} has an invalid selection.`, q.key);
      }
    }
  }
}

/**
 * Computes estimate_low / estimate_high from a validated config + answers.
 *
 *   base_material_cost = roof_area * rate_per_sqft * (1 + waste_factor)
 *   tear_off_cost       = roof_area * tear_off_per_sqft
 *   adjusted_subtotal   = (base_material_cost + tear_off_cost) * pitch_multiplier * stories_multiplier
 *   mid_estimate        = adjusted_subtotal + permit_flat_fee
 *   estimate_low        = mid_estimate * (1 - spread)
 *   estimate_high       = mid_estimate * (1 + spread)
 */
export function calculateEstimate(config, answers) {
  const { questions, modifiers } = config;

  const roofArea = Number(answers.roof_area || 0);

  const materialOpt = getSelectedOption(getQuestion(questions, 'material'), answers.material);
  const pitchOpt = getSelectedOption(getQuestion(questions, 'pitch'), answers.pitch);
  const layersOpt = getSelectedOption(getQuestion(questions, 'layers'), answers.layers);
  const storiesOpt = getSelectedOption(getQuestion(questions, 'stories'), answers.stories);

  const ratePerSqft = Number(materialOpt?.rate_per_sqft ?? 0);
  const pitchMult = Number(pitchOpt?.multiplier ?? 1.0);
  const tearOffPerSqft = Number(layersOpt?.tear_off_per_sqft ?? 0);
  const storiesMult = Number(storiesOpt?.multiplier ?? 1.0);

  const wasteFactor = Number(modifiers.waste_factor ?? 0.10);
  const permitFee = Number(modifiers.permit_flat_fee ?? 350);
  const spreadPct = Number(modifiers.range_spread_pct ?? 12) / 100;

  const baseMaterialCost = roofArea * ratePerSqft * (1 + wasteFactor);
  const tearOffCost = roofArea * tearOffPerSqft;
  const subtotal = (baseMaterialCost + tearOffCost) * pitchMult * storiesMult;
  const midEstimate = subtotal + permitFee;

  const estimateLow = Math.round(midEstimate * (1 - spreadPct));
  const estimateHigh = Math.round(midEstimate * (1 + spreadPct));

  return { estimate_low: estimateLow, estimate_high: estimateHigh };
}
