// server/src/controllers/configController.js
import { getActiveConfig, publishNewConfig } from '../models/configModel.js';

/**
 * GET /api/config — public. Returns only ACTIVE questions, sorted by their
 * position in the stored array (which the owner panel controls via
 * reordering — for this build, order = array order, no separate "order"
 * field, see DECISIONS.md). No rates are hidden: rates/multipliers are
 * required by the frontend to render option labels correctly, but the
 * frontend never uses them for calculation — that happens server-side in
 * POST /api/estimate regardless of what the client sends.
 */
export function getPublicConfig(req, res) {
  const config = getActiveConfig();
  if (!config) return res.status(404).json({ error: 'No active configuration found' });

  const activeQuestions = config.questions.filter((q) => q.active);

  res.json({
    config_version: config.config_version,
    business: config.business,
    questions: activeQuestions,
  });
}

/**
 * GET /api/admin/config — protected. Returns the FULL config including
 * inactive questions, so the owner panel can re-enable them.
 */
export function getAdminConfig(req, res) {
  const config = getActiveConfig();
  if (!config) return res.status(404).json({ error: 'No active configuration found' });
  res.json(config);
}

/**
 * PUT /api/admin/config — protected. Replaces the full config document
 * (business info, questions, modifiers) and publishes it as a new version.
 * We do a whole-document replace rather than a field-by-field patch because
 * the owner panel always sends the full edited document back — simpler to
 * reason about and avoids partial-update race conditions between Dale and
 * Marcus editing at the same time (acceptable risk for this build size,
 * documented in DECISIONS.md as an out-of-scope concern for concurrent edits).
 */
export function updateConfig(req, res) {
  const { business, questions, modifiers } = req.body;

  if (!business || !Array.isArray(questions) || !modifiers) {
    return res.status(400).json({ error: 'business, questions[], and modifiers are required.' });
  }

  for (const q of questions) {
    if (!q.key || !q.label || !q.type) {
      return res.status(400).json({ error: 'Every question needs a key, label, and type.' });
    }
  }

  const normalizedQuestions = questions.map((q) => ({
    ...q,
    ...(q.options && {
      options: q.options.map((opt) => ({
        ...opt,
        ...(opt.rate_per_sqft !== undefined && { rate_per_sqft: Number(opt.rate_per_sqft) }),
        ...(opt.multiplier !== undefined && { multiplier: Number(opt.multiplier) }),
        ...(opt.tear_off_per_sqft !== undefined && { tear_off_per_sqft: Number(opt.tear_off_per_sqft) }),
      })),
    }),
  }));

  const normalizedModifiers = {
    waste_factor: Number(modifiers.waste_factor),
    permit_flat_fee: Number(modifiers.permit_flat_fee),
    range_spread_pct: Number(modifiers.range_spread_pct),
  };

  const updated = publishNewConfig({ business, questions: normalizedQuestions, modifiers: normalizedModifiers });
  res.json(updated);
}
