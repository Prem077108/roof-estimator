// server/src/controllers/authController.js
import bcrypt from 'bcryptjs';
import { db } from '../config/db.js';
import { signToken } from '../middleware/auth.js';

export function login(req, res) {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'username and password are required.' });
  }

  const owner = db.prepare('SELECT * FROM owners WHERE username = ?').get(username);
  if (!owner || !bcrypt.compareSync(password, owner.password_hash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = signToken({ sub: owner.id, username: owner.username });
  res.json({ token, username: owner.username });
}
