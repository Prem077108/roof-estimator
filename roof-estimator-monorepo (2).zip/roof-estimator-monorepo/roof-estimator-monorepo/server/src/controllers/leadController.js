// server/src/controllers/leadController.js
import { listLeads } from '../models/leadModel.js';

export function getLeads(req, res) {
  res.json(listLeads());
}
