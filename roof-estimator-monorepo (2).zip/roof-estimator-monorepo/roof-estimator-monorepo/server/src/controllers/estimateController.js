// server/src/controllers/estimateController.js
import { getActiveConfig } from '../models/configModel.js';
import { createLead } from '../models/leadModel.js';
import { calculateEstimate, validateAnswers, ValidationError } from '../services/calculator.js';

export function postEstimate(req, res) {
  const { name, phone, email, answers } = req.body;

  if (!name || !phone || !email) {
    return res.status(400).json({ error: 'name, phone, and email are required.' });
  }
  if (!answers || typeof answers !== 'object') {
    return res.status(400).json({ error: 'answers object is required.' });
  }

  const config = getActiveConfig();
  if (!config) return res.status(404).json({ error: 'No active configuration found' });

  try {
    validateAnswers(config, answers);
  } catch (err) {
    if (err instanceof ValidationError) {
      return res.status(400).json({ error: err.message, field: err.field });
    }
    throw err;
  }

  const { estimate_low, estimate_high } = calculateEstimate(config, answers);

  const lead = createLead({
    name,
    phone,
    email,
    answers,
    config_version: config.config_version,
    estimate_low,
    estimate_high,
  });

  res.status(201).json({
    lead_id: lead.id,
    currency: config.business.currency,
    estimate_low,
    estimate_high,
  });
}
