// server/src/models/leadModel.js
import { randomUUID } from 'crypto';
import { db } from '../config/db.js';

function rowToLead(row) {
  return {
    id: row.id,
    captured_at: row.captured_at,
    config_version: row.config_version,
    name: row.name,
    phone: row.phone,
    email: row.email,
    answers: JSON.parse(row.answers_json),
    estimate_low: row.estimate_low,
    estimate_high: row.estimate_high,
  };
}

export function createLead({ name, phone, email, answers, config_version, estimate_low, estimate_high }) {
  const id = `ld_${randomUUID().slice(0, 8)}`;
  const captured_at = new Date().toISOString();

  db.prepare(
    `INSERT INTO leads (id, captured_at, config_version, name, phone, email, answers_json, estimate_low, estimate_high)
     VALUES (@id, @captured_at, @config_version, @name, @phone, @email, @answers_json, @estimate_low, @estimate_high)`
  ).run({ id, captured_at, config_version, name, phone, email, answers_json: JSON.stringify(answers), estimate_low, estimate_high });

  return rowToLead({ id, captured_at, config_version, name, phone, email, answers_json: JSON.stringify(answers), estimate_low, estimate_high });
}

export function listLeads() {
  const rows = db.prepare('SELECT * FROM leads ORDER BY captured_at DESC').all();
  return rows.map(rowToLead);
}
