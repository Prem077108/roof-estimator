// server/src/models/configModel.js
import { db } from '../config/db.js';

function rowToConfig(row) {
  if (!row) return null;
  return {
    config_version: row.config_version,
    business: JSON.parse(row.business_json),
    questions: JSON.parse(row.questions_json),
    modifiers: JSON.parse(row.modifiers_json),
    created_at: row.created_at,
  };
}

export function getActiveConfig() {
  const row = db.prepare('SELECT * FROM configs WHERE is_active = 1 ORDER BY config_version DESC LIMIT 1').get();
  return rowToConfig(row);
}

/**
 * Publishes a new config version. We INSERT a new row rather than UPDATE the
 * existing one, and flip is_active, so old config versions stay intact in
 * the table. This is what lets historical leads reference the exact
 * config_version they were captured under (see seed.js notes on ld_0917),
 * and gives us a free audit trail if the "config version history" stretch
 * goal is picked up later.
 */
export function publishNewConfig({ business, questions, modifiers }) {
  const current = getActiveConfig();
  const nextVersion = (current?.config_version || 0) + 1;

  const tx = db.transaction(() => {
    db.prepare('UPDATE configs SET is_active = 0 WHERE is_active = 1').run();
    db.prepare(
      `INSERT INTO configs (config_version, business_json, questions_json, modifiers_json, is_active)
       VALUES (?, ?, ?, ?, 1)`
    ).run(nextVersion, JSON.stringify(business), JSON.stringify(questions), JSON.stringify(modifiers));
  });
  tx();

  return getActiveConfig();
}
