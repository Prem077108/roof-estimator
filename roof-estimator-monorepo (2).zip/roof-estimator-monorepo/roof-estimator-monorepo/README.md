# Northline Roofing — Config-Driven Estimator & Owner Panel

A two-surface app for Northline Roofing & Exteriors:

- **Public estimator** (`/`) — a mobile-friendly, multi-step form that reads its
  questions, options, and labels entirely from the API at runtime, and returns a
  server-calculated cost range.
- **Owner panel** (`/admin`) — a login-protected dashboard where Dale or Marcus can
  edit prices/multipliers, toggle questions on or off, and review captured leads,
  with changes going live on the public estimator immediately, with no redeploy.

> **Live URLs:** _add your deployed links here once you've deployed —
> `https://your-frontend.vercel.app` and `https://your-backend.onrender.com`._
>
> **Owner panel test login:** `admin` / `roofing2026!` (change these via env vars
> before a real deploy — see below).

## Project structure

```
roof-estimator-monorepo/
├── client/     # React (Vite) + Tailwind — public estimator + owner panel
├── server/     # Express API + SQLite (better-sqlite3)
├── DECISIONS.md
├── AI_LOG.md
└── README.md
```

## Running locally from a clean clone

Requires Node.js v18+.

```bash
git clone <your-repo-url>
cd roof-estimator-monorepo

# 1. Backend
cd server
cp .env.example .env      # defaults work out of the box for local dev
npm install
npm run seed               # creates server/data/app.db and loads the seed config + leads
npm start                  # → http://localhost:4000

# 2. Frontend (in a second terminal)
cd client
cp .env.example .env      # points at http://localhost:4000/api by default
npm install
npm run dev                 # → http://localhost:5173
```

Then open:
- `http://localhost:5173` for the public estimator
- `http://localhost:5173/admin/login` for the owner panel (`admin` / `roofing2026!`)

Re-running `npm run seed` at any point wipes and reloads the config/leads/owner
tables back to the original seed state — handy for demos.

## Environment variables

**server/.env**

| Variable | Description | Default |
|---|---|---|
| `PORT` | API port | `4000` |
| `JWT_SECRET` | Secret used to sign owner-panel auth tokens | `dev-secret-change-me` (**change in production**) |
| `ADMIN_USERNAME` | Owner panel login username (used only on first seed) | `admin` |
| `ADMIN_PASSWORD` | Owner panel login password (used only on first seed) | `roofing2026!` |
| `DATABASE_URL` | Absolute path to the SQLite file | `server/data/app.db` |

**client/.env**

| Variable | Description | Default |
|---|---|---|
| `VITE_API_URL` | Base URL of the API | `http://localhost:4000/api` |

## Deploying (not done for you — do this before submitting)

This project was built and tested locally in an environment without access to
GitHub, Vercel, Render, etc., so **deployment and git history are things you need
to do yourself** with this codebase. Roughly:

1. `git init`, commit in logical chunks as you review each part (schema → API →
   frontend → docs), then push to a new GitHub repo. Don't squash it into one commit.
2. **Backend:** deploy `server/` to Render or Railway.
   - Set `JWT_SECRET`, `ADMIN_USERNAME`, `ADMIN_PASSWORD` as environment variables
     (don't ship the defaults to production).
   - SQLite needs a persistent disk (Render's "Persistent Disk" add-on, or
     Railway's volumes) so the database survives redeploys — otherwise every
     deploy wipes leads and config edits. If you'd rather avoid managing a disk,
     swap `DATABASE_URL`/`better-sqlite3` for a managed Postgres instance; the
     schema in `server/src/config/db.js` is plain SQL and ports over directly.
   - Run `npm run seed` once against the deployed instance (e.g. via a one-off
     shell/job on the host) to create the initial config and owner account.
3. **Frontend:** deploy `client/` to Vercel or Netlify, with `VITE_API_URL` set
   to your deployed backend's `/api` URL.
4. Update the live URLs at the top of this README.

## What was verified before writing this README

- Every question, option, label, and rate on the public estimator comes from
  `GET /api/config` — there is no pricing data anywhere in `client/src`.
- Changing a rate in the owner panel and reloading the public estimator (no
  restart) reflects the new price immediately.
- The owner panel is unreachable without a valid login; `/api/admin/*` returns
  401 without a bearer token.
- Calculation happens entirely in `server/src/services/calculator.js` — the
  browser never receives rates or formula logic, only the final range.
